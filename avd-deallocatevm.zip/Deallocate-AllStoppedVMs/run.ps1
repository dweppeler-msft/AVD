# Input bindings are passed in via param block.
param($Timer)

# Get the current universal time in the default string format.
$currentUTCtime = (Get-Date).ToUniversalTime()

# The 'IsPastDue' property is 'true' when the current function invocation is later than scheduled.
if ($Timer.IsPastDue) {
    Write-Host "PowerShell timer is running late!"
}

# Write an information log with the current time.
Write-Host "PowerShell timer trigger function ran! TIME: $currentUTCtime"

$StoppedVMs = Get-AzVM -ResourceGroupName $env:ResourceGroupName -Status | Where-Object {($_.powerstate -eq "VM stopped")}
if ($null -ne $StoppedVMs){
    foreach ($VM in $StoppedVMs){
        Write-Host "VM $($VM.Name) will be deallocated now..."
        $StopVM = Stop-AzVM -Name $VM.Name -ResourceGroupName $env:ResourceGroupName  -Force
        If ($StopVM.Status -eq "Succeeded") {
        Write-Host "VM $($VM.Name) was successfully deallocated..."
        } else {
        Write-Host ("Something went wrong! Please check the Azure activity log ...")
        }
    }   
} else {
    Write-Host ("No VMs could be found in the status stopped...")
}